package Controller;
public interface GastoCalculable {
    public abstract double calcularGasto();
}
