package Controller;

import java.util.ArrayList;
import java.util.Random;
import View.*;
public class OperacionesContribuyente {

    public static Contribuyente crearYProcesarContribuyente(int contadorUsuarios) { // Método público
        ArrayList<Factura> facturas = GeneradorFacturas.generarFacturas();
        Contribuyente usuario = new Contribuyente(
            GeneradorDatos.generarNombres(), 
            GeneradorDatos.generarSueldosDeUnAnio(), 
            GeneradorDatos.generarDireccion(), 
            GeneradorDatos.generarCedulas()
        );

        String archivoFacturas = ManejoArchivos.guardarFacturasEnArchivo(facturas, contadorUsuarios, usuario);
        usuario.setFacturas(ManejoArchivos.leerFacturasDeArchivo(archivoFacturas));
        procesarImpuestos(usuario);
        ManejoArchivos.guardarContribuyente(usuario);

        return usuario;
    }

    private static void procesarImpuestos(Contribuyente usuario) {
        Random r = new Random();
        if (r.nextBoolean()) {
            usuario.setDividend(GeneradorDatos.generarDividendos());
            usuario.setDividendTaxRate(GeneradorDatos.generarTasasImpositivasDividendos());
        }
        usuario.calcularImpuestos();
        usuario.generarReporteImpuestos();
    }

    public static void leerYMostrarContribuyentes(ArrayList<Contribuyente> usuarios) { // Método público
        for (Contribuyente usuario : usuarios) {
            Contribuyente cliente = ManejoArchivos.leerContribuyente(usuario.getName());
            System.out.println("Contribuyente con su reporte leído desde " + usuario.getName() + ".dat");
            System.out.println(cliente.toString());
        }
    }
}
