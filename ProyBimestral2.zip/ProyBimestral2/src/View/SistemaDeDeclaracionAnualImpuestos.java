package View;

import java.util.ArrayList;
import java.util.Scanner;
import Controller.OperacionesContribuyente;
import Controller.Contribuyente;

public class SistemaDeDeclaracionAnualImpuestos {
    public static void main(String[] args) {
        ArrayList<Contribuyente> usuarios = new ArrayList<>();
        Scanner in = new Scanner(System.in);
        boolean continuar = true;
        int contadorUsuarios = 0;

        while (continuar) {
            usuarios.add(OperacionesContribuyente.crearYProcesarContribuyente(contadorUsuarios));
            contadorUsuarios++;

            System.out.println("¿Desea ingresar otro Contribuyente? (Si / No)");
            if (!in.next().equalsIgnoreCase("Si")) {
                continuar = false;
            }
        }

        OperacionesContribuyente.leerYMostrarContribuyentes(usuarios);
    }
}
